import Typography from '@mui/material/Typography';


export default function Home() {
    return (
        <Typography>
            This is the Services page!
        </Typography>
    )
}